package ioc.ddl;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class SignUp extends AppCompatActivity {

    private Button back;
    private TextView errMsg;
    private EditText user, passwd;
    private String userIn, passwdIn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        getSupportActionBar().hide();

        user = findViewById(R.id.DNIuser);
        passwd = findViewById(R.id.userPasswd);
        back = findViewById(R.id.backButt);

        back.setOnClickListener(v -> {

            Intent i = new Intent(this, LogIn.class);
            startActivity(i);

        });

        userIn = user.getText().toString();
        passwdIn = passwd.getText().toString();

        if (!(userIn.contains("@"))) {



        }





    }

}