package ioc.ddl;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class LogIn extends AppCompatActivity {

    private Handler handler;
    private TextView errMsg;
    private Runnable runnable;
    private Button signUpBut, loginBtn;
    private EditText DNIuser, userPasswd;
    private ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);

        errMsg = findViewById(R.id.errMsg);
        DNIuser = findViewById(R.id.DNIuser);
        loginBtn = findViewById(R.id.loginBtn);
        userPasswd = findViewById(R.id.userPasswd);
        signUpBut = findViewById(R.id.signUpBtn);



        getSupportActionBar().hide();

        signUpBut.setOnClickListener(v -> {

            Intent i = new Intent(this, SignUp.class);
            startActivity(i);

        });

        String user = DNIuser.getText().toString();

        loginBtn.setOnClickListener(v -> {

            //if (user.equals("")) Toast.makeText(this, "INTRODUCE A DNI", Toast.LENGTH_LONG).show();

            if (!(user.contains("@")) && !(user.contains(".")))
                Toast.makeText(this, "DATA ERROR", Toast.LENGTH_LONG).show();


        });


    }


}